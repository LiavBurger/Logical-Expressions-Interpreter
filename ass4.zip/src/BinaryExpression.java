//Liav Burger 208277871
/**
 * Classname: BinaryExpression.
 */
public abstract class BinaryExpression extends BaseExpression {
    /**
     * Constructor.
     * @param e1 can be any expression.
     * @param e2 can be any expression.
     */
    public BinaryExpression(Expression e1, Expression e2) {
        super(e1,e2);
    }
}
